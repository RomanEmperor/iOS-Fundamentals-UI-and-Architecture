//
//  ViewController.swift
//  ResponsiveUIDesign
//
//  Created by Roman Emperor on 8/23/19.
//  Copyright © 2019 Roman Emperor. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

